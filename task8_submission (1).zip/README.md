
# Task 8: Stored Procedures and Functions

## Objective:
To learn and implement reusable SQL blocks using stored procedures and functions.

## Files Included:
- `task8.sql`: Contains one stored procedure (IncreaseSalary) and one function (GetDepartmentName).

## Description:
- **Stored Procedure - IncreaseSalary**: Takes an employee ID and increment value to update the salary.
- **Function - GetDepartmentName**: Accepts a department ID and returns the corresponding department name.

## Tools Used:
- MySQL Workbench

## Usage:
1. Open MySQL Workbench or your preferred SQL client.
2. Execute the SQL commands in `task8.sql`.
3. Call the procedure or function as needed for testing.

## Author:
Elevate Labs SQL Developer Internship Participant
