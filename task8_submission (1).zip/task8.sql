
-- Stored Procedure: IncreaseSalary
DELIMITER //
CREATE PROCEDURE IncreaseSalary(IN emp_id INT, IN increment DECIMAL(10,2))
BEGIN
    UPDATE Employees
    SET salary = salary + increment
    WHERE id = emp_id;
END;
//
DELIMITER ;

-- Function: GetDepartmentName
DELIMITER //
CREATE FUNCTION GetDepartmentName(dept_id INT)
RETURNS VARCHAR(100)
DETERMINISTIC
BEGIN
    DECLARE dept_name VARCHAR(100);
    SELECT name INTO dept_name FROM Departments WHERE id = dept_id;
    RETURN dept_name;
END;
//
DELIMITER ;
